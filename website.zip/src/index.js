const express = require("express");
const cors = require("cors");
// const puppeteer = require('puppeteer');
const userRoutes = require("../router/user");
const appointmentRoutes = require("../router/appointment");
const categoryRoutes = require("../router/category");

const rateRoutes = require("../router/rate");

const uploadController = require("../router/upload");

const rateHistoryRoutes = require("../router/ratehistory");

const sliderRouter = require("../router/sliderItem");
const bannerRouter = require("../router/banner");
const bannerfullwidthRouter = require("../router/bannerfullwidth");
const subcategoryRoutes = require("../router/subcategory");
const InitiateMongoServer = require("../db/mongoose");
const optionlistRouter = require("../router/optionlist");
const aboutlistRouter = require("../router/about");
const testimonialRouter = require("../router/testimonial");
const contactlistRouter = require("../router/contact");
const pricelistRouter = require("../router/price");
const productlistRouter = require("../router/productlist");
const optionRouter = require("../router/option");
const enqcategoriesRouter = require("../router/enquirycategory");
const enquiryRouter = require("../router/enquiry");
const customRequestRouter = require("../router/customreq");
const scheduleRouter = require("../router/schedule");
InitiateMongoServer();
const app = express();
const port = process.env.PORT || 3012;
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("storage"));

app.use("/api/users", userRoutes);
app.use("/api/schedule", appointmentRoutes);
app.use("/api/category", categoryRoutes);

app.use("/api/rates", rateRoutes);

app.use("/api/upload", uploadController);

app.use("/api/ratehistory", rateHistoryRoutes);

app.use("/api/sliders", sliderRouter);
app.use("/api/banners", bannerRouter);
app.use("/api/bannerlist", bannerfullwidthRouter);
app.use("/api/schedule", appointmentRoutes);
app.use("/api/subcategory", subcategoryRoutes);
app.use("/api/optionlist", optionlistRouter);
app.use("/api/aboutlist", aboutlistRouter);
app.use("/api/testlist", testimonialRouter);
app.use("/api/contact", contactlistRouter);
app.use("/api/price", pricelistRouter);
app.use("/api/subcategory", subcategoryRoutes);
app.use("/api/productlist", productlistRouter);
app.use("/api/option", optionRouter);
app.use("/api/enqcategories", enqcategoriesRouter);
app.use("/api/enquires", enquiryRouter);
app.use("/api/customreq", customRequestRouter);
app.use("/api/schedules", scheduleRouter);
app.get("/api", (req, res) => {
  res.send("Welcome");
});

app.listen(port, () => {
  console.log("server is up on " + port);
});
